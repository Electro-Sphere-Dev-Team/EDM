package EDM.edm.main.api;

import net.minecraft.item.EnumArmorMaterial;

public class ArmorMaterialAPI 
{
	public static EnumArmorMaterial Black_Diamonds;
	public static EnumArmorMaterial Blue_Diamonds;
	public static EnumArmorMaterial Gray_Diamonds;
	public static EnumArmorMaterial Green_Diamonds;

}
