package EDM.edm.main.api;

import net.minecraft.item.ItemArmor;

public class ArmorAPI {
	//Black Diamond Armor
	public static ItemArmor Black_H;
	public static ItemArmor Black_C;
	public static ItemArmor Black_L;
	public static ItemArmor Black_B;
	//Blue Diamond Armor
	public static ItemArmor Blue_H;
	public static ItemArmor Blue_C;
	public static ItemArmor Blue_L;
	public static ItemArmor Blue_B;
	//Gray Diamond Armor
	public static ItemArmor Gray_H;
	public static ItemArmor Gray_C;
	public static ItemArmor Gray_L;
	public static ItemArmor Gray_B;
	//Green Diamond
	public static ItemArmor Green_H;
	public static ItemArmor Green_C;
	public static ItemArmor Green_L;
	public static ItemArmor Green_B;
	//Orange Diamond
	public static ItemArmor Orange_H;
	public static ItemArmor Orange_C;
	public static ItemArmor Orange_L;
	public static ItemArmor Orange_B;
	//Pink Diamond
	public static ItemArmor Pink_H;
	public static ItemArmor Pink_C;
	public static ItemArmor Pink_L;
	public static ItemArmor Pink_B;

}
