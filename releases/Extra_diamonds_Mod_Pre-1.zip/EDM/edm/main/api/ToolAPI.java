package EDM.edm.main.api;

import net.minecraft.item.Item;

public class ToolAPI 
{
		/*Black Diamond*/
		public static Item Black_Pickaxe;
		public static Item Black_Axe;
		public static Item Black_Shovel;
		public static Item Black_Sword;
		
		/*Blue Diamond*/
		public static Item Blue_Pickaxe;
		public static Item Blue_Axe;
		public static Item Blue_Shovel;
		public static Item Blue_Sword;
		
		/*Gray Diamond*/
		public static Item Gray_Pickaxe;
		public static Item Gray_Axe;
		public static Item Gray_Shovel;
		public static Item Gray_Sword;
}
