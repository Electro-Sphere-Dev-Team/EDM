package EDM.edm.main.api;

import EDM.edm.main.block.BlockOre;

public class OreAPI {

	public static BlockOre Black_O;
	public static BlockOre Blue_O;
	public static BlockOre Gray_O;
	public static BlockOre Green_O;
	public static BlockOre Orange_O;


	

}
