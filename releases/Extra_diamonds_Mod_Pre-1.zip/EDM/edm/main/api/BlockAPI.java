package EDM.edm.main.api;

import net.minecraft.block.Block;

public class BlockAPI {

	public static Block Black_B;
	public static Block Blue_B;
	public static Block Gold_B;
	public static Block Gray_B;
	public static Block Green_B;
	public static Block Orange_B;
	public static Block Pink_B;
	public static Block Purple_B;
	public static Block Red_B;
	public static Block White_B;
	public static Block Yellow_B;
}
