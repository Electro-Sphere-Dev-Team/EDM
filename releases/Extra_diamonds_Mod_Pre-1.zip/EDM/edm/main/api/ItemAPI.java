package EDM.edm.main.api;

import net.minecraft.item.Item;

public class ItemAPI {

	public static Item Black;
	public static Item Blue;
	public static Item Gold;
	public static Item Gray;
	public static Item Green;
	public static Item Orange;
	public static Item Pink;
	public static Item Purple;
	public static Item Red;
	public static Item White;
	public static Item Yellow;
}
